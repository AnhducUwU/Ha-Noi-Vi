# Ha Noi Vi
A culinary website dedicated to exploring Hanoi’s cuisine, created by Group 1, Class 24TO, at Luong The Vinh High School for the Gifted.
OUR TEAM

Nguyễn Huy Anh Đức — Team Leader

Phạm Hoàng Bách — Team Member

Lê Tấn Phát — Team Member

Group 1 | Class 24TO
Luong The Vinh High School for the Gifted

## Hình ảnh và khả năng tương thích

- Website đang sử dụng các ảnh PNG độ phân giải cao trong `assets/images/` để tương thích rộng với trình duyệt và công cụ xem ảnh.
- Các bản SVG gốc được giữ lại cùng tên để chỉnh sửa và phóng to không giảm chất lượng.
- Ảnh món ăn được xuất ở mức 3x; ảnh nền đặt chỗ được xuất ở mức 2x để cân bằng độ nét và dung lượng.
- Các tệp HTML, CSS và JavaScript được giữ nguyên vì chúng điều khiển bố cục, nội dung và chức năng tương tác của website.
